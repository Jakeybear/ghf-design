import { MockData } from '../data/data'

//export const FETCH_DATA = 'fetch_data'
export const FETCH_LAST = 'fetch_last'
export const FETCH_NEXT = 'fetch_next'

//export function fetchData(){
//
//    const question = MockData.questionData
//    return{
//        type:FETCH_DATA,
//        payload: question
//    }
//}

export function fetchLast(currentIndex){
    const lastIndex = currentIndex-1
    return{
        type:FETCH_LAST,
        payload: lastIndex
    }
}

export function fetchNext(currentIndex){

    const nextIndex = currentIndex+1
    return{
        type:FETCH_NEXT,
        payload: nextIndex
    }
}

