import React, { Component } from 'react';
import Question from './question'
import Pre from './pre'
import Next from './Next'
import SubmitTest from './submitTest'
export default class App extends Component {

  render() {
    return (
      <div>
        <h1>Interview Question</h1>
        <hr/>
        <Question />
        <div>
            <Pre />
            <Next />
        </div>
        <hr/>
        <SubmitTest />
      </div>
    );
  }
}
