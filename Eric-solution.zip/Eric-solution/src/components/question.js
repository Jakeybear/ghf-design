import React, { Component } from 'react'
//import { fetchData } from '../actions'
import { connect } from 'react-redux'
import _ from 'lodash'

class Question extends Component{

    //componentDidMount(){
    //    //this.props.fetchData()
    //}

    renderAnswer(index){
        return (
            <p>{this.props.question.answers[index].answer}</p>
        )
    }

    renderOption(question){
        var answers = _.mapKeys(question.answers,'id')
        console.log(answers)
        return _.map(answers,option=>{
            console.log(option)
            return(
            <div className="radio" key={option.id}>
                <label>
                    <input type="radio" name="optradio" value={option.points}/>
                    {option.answer}
                </label>
            </div>
            )
        })
    }

    renderQuestions(){
        console.log(this.props.questionsList)
        return _.map(this.props.questionsList, question=>{
            return(
                <form className="form-group"  key={question.id} style={{display:this.props.currentIndex==question.id? 'block':'none'}}>
                    {this.renderOption(question)}
                </form>
            )
        })
    }

    render(){
        const {
            question
            } = this.props

        return(
            <div className="form-control">
                <h2>{question.title}</h2>
                <p>{question.content}</p>
                <div>
                    {this.renderQuestions()}
                </div>
            </div>
        )
    }
}

function mapStateToProps(state){
    //console.log(state)
    return {
        question: state.questionData.currentQuestion,
        questionsList:state.questionData.questionsList,
        currentIndex:state.questionData.currentIndex
    }
}

export default connect(mapStateToProps)(Question);