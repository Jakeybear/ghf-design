import React, { Component } from 'react'
import {fetchLast} from '../actions'
import { connect } from 'react-redux'

class Pre extends Component{

    lastQuestion(){
        this.props.fetchLast(this.props.currentIndex)
    }

    render(){
        const {
            currentIndex
            }=this.props
        return(
            <button onClick={this.lastQuestion.bind(this,currentIndex)} className="btn btn-sm btn-primary " disabled={currentIndex<2} style={{margin:5}}>Pre</button>
        )
    }
}

function mapPropsToState(state){
    return{
        currentIndex:state.questionData.currentIndex
    }
}

export default connect(mapPropsToState, {fetchLast})(Pre)