import React, { Component } from 'react'
import {fetchNext} from '../actions'
import { connect } from 'react-redux'

class Next extends Component{

    nextQuestion(){

        this.props.fetchNext(this.props.currentIndex)
    }

    render(){
        const {
            currentIndex,
            totalIndex
            }=this.props
        return(
            <button onClick={this.nextQuestion.bind(this,currentIndex)} className="btn btn-sm btn-primary" disabled={currentIndex>=totalIndex} style={{margin:5}}>Next</button>
        )
    }
}

function mapPropsToState(state){
    return{
        currentIndex:state.questionData.currentIndex,
        totalIndex:state.questionData.totalIndex
    }
}

export default connect(mapPropsToState, {fetchNext})(Next)