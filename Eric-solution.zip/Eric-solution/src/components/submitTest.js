import React, {Component} from 'react'

class SubmitTest extends Component{
    submitQuiz(){
        var checkOption = document.getElementsByName('optradio')
        console.log(checkOption)
        var sum = 0
        for(let i=0; i<checkOption.length; i++){
            if(checkOption[i].checked){
                sum += parseInt(checkOption[i].value)
            }
        }
        alert(`YOUR FINAL SCORE IS ${sum}`)
    }

    render(){
        return(
            <button onClick={this.submitQuiz.bind(this)}>
                Submit
            </button>
        )
    }
}

export default SubmitTest;