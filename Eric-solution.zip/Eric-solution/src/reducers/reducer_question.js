import { FETCH_LAST, FETCH_NEXT} from '../actions'
import 'lodash'
import {MockData} from '../data/data'

const currentIndex = 1
const Questions = _.mapKeys(MockData.questionData, 'id')
const totalIndex = MockData.questionData.length


const initialState = {
    currentIndex: currentIndex,
    currentQuestion:Questions[1],
    totalIndex: totalIndex,
    questionsList:Questions
}

export default function(state=initialState,action){
    switch(action.type){
        //case FETCH_DATA:
        //    console.log(_.mapKeys(action.payload, 'id'))
        //    return _.mapKeys(action.payload, 'id');
        case FETCH_LAST:
            console.log(action.payload)
            return Object.assign({},state,{
                currentIndex: action.payload,
                currentQuestion: Questions[action.payload]
            })
        case FETCH_NEXT:
            console.log(action.payload)
            return Object.assign({},state,{
                currentIndex: action.payload,
                currentQuestion: Questions[action.payload]
            })
        default:
            return state
    }
}