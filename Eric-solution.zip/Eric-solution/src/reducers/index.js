import { combineReducers } from 'redux';
import reducer_question from './reducer_question'

const rootReducer = combineReducers({
    questionData: reducer_question
});

export default rootReducer;
