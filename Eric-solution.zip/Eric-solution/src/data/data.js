export const MockData ={
    "questionData": [
    {
        "id": 1,
        "title": "Question 1",
        "content": "This is the content for Question 1",
        "answers":
            [
                {"id": 1, "answer": "answer11", "points": 2},
                {"id": 2, "answer": "answer12", "points": 1},
                {"id": 3, "answer": "answer13", "points": 0},
            ]
        ,
        "selected": -1
    },
    {
        "id": 2,
        "title": "Question 2",
        "content": "This is the content for Question 2",
        "answers":
            [
                {"id": 1, "answer": "answer21", "points": 2},
                {"id": 2, "answer": "answer22", "points": 1},
                {"id": 3, "answer": "answer23", "points": 0},
            ]
        ,
        "selected": -1
    },
    {
        "id": 3,
        "title": "Question 3",
        "content": "This is the content for Question 3",
        "answers":
            [
                {"id": 1, "answer": "answer31", "points": 2},
                {"id": 2, "answer": "answer32", "points": 1},
                {"id": 3, "answer": "answer33", "points": 0},
            ]
        ,
        "selected": -1
    },

]
};



